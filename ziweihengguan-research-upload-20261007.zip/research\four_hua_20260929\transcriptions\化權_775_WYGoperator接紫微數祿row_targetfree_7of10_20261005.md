# §775 WYG卷一權operator接《紫微數》固定祿row：target-free先生成Q0，開答案後7/10，殘差仍精確乙壬癸

日期：2026-10-05

## 一、目的

承接§773–774，現在只抽取《星學大成》卷一的 general operator，不把單曜章【炁／計舊層】直接跨映射到紫微。

流程固定：

1. 先讀《紫微數》既有固定祿row；
2. operator只取自WYG卷一；
3. 先生成完整Q0並凍結；
4. 最後才打開1581成熟化權表做validation。

新增可重跑：

- `research/four_hua_20260929/quan_775_wyg_operator_to_ziweishu_lu_blind_validation_20261005.js`

## 二、輸入A：《紫微數》固定祿row

十干固定祿row：

| 干 | 甲 | 乙 | 丙 | 丁 | 戊 | 己 | 庚 | 辛 | 壬 | 癸 |
|---|---|---|---|---|---|---|---|---|---|---|
| 祿 | 廉貞 | 天機 | 天同 | 太陰 | 貪狼 | 武曲 | 太陽 | 巨門 | 天梁 | 破軍 |

本節不重新選祿row，只沿用已確立的早期固定星祿欄。

## 三、輸入B：WYG卷一 general operator

§774已固定兩個等價視角：

固定carrier視角：

`QuanStem(body)=LuStem(body)+1`

十干row視角：

`Quan(g)=Lu(g-1)`

跨到固定星祿row時使用第二式。

此operator在生成Q0前已固定，沒有讀成熟紫微化權答案。

## 四、target-free先生成Q0

把祿row整體取前一干 carrier：

| 干 | 甲 | 乙 | 丙 | 丁 | 戊 | 己 | 庚 | 辛 | 壬 | 癸 |
|---|---|---|---|---|---|---|---|---|---|---|
| Q0 | 破軍 | 廉貞 | 天機 | 天同 | 太陰 | 貪狼 | 武曲 | 太陽 | 巨門 | 天梁 |

即：

> 【破、廉、機、同、陰、貪、武、陽、巨、梁】

到這一步為止，不使用成熟權target。

## 五、最後才開成熟化權答案

1581成熟權：

| 干 | 甲 | 乙 | 丙 | 丁 | 戊 | 己 | 庚 | 辛 | 壬 | 癸 |
|---|---|---|---|---|---|---|---|---|---|---|
| 成熟權 | 破軍 | 天梁 | 天機 | 天同 | 太陰 | 貪狼 | 武曲 | 太陽 | 紫微 | 巨門 |

validation：

- 命中：甲、丙、丁、戊、己、庚、辛
- 共：**7/10**
- 殘差：**乙、壬、癸**

三格精確為：

- 乙：Q0廉貞 → 成熟天梁
- 壬：Q0巨門 → 成熟紫微
- 癸：Q0天梁 → 成熟巨門

與此前Q0殘差完全一致，沒有因本輪重建而改動。

## 六、全局carrier pool只差一進一出

Q0 pool與成熟權pool比較：

Q0獨有：

> 廉貞

成熟權獨有：

> 紫微

巨門、天梁都仍在兩邊，只是壬癸位置重掛。

所以全局結構仍是：

1. pool level：廉貞退、紫微入；
2. position level：乙壬癸三格重新接位。

這與既有§713之後的分解一致。

## 七、為什麼本節不使用WYG炁／計+8例外

§773–774已證WYG單曜章有：

- 8曜新權+1
- 炁／計舊權+8

但本節刻意不把這個 mixed chapter table 直接投影到紫微，原因是§731已證：

> 十變曜physical body → 固定星的逐體對應，不是文本明寫的直接identity dictionary；先前那套body→star關係只是由同位row誘導的 positional codebook。

因此若直接說：

> 「炁、計是例外，所以紫微某兩顆星也照+8」

會重新偷渡未證的physical-body identity。

本節只取卷一 general operator，是證據最乾淨、自由度最低的跨書方式。

## 八、這一輪真正確認了什麼

現在可以把「7/10 Q0」再升一級方法學可信度：

以前：

> 已知一干位移很好用，生成7/10。

現在：

> 先由WYG卷一自己的十變曜總公式固定row operator【Quan(g)=Lu(g−1)】，再接《紫微數》固定祿row；完全不調參即可生成同一Q0，最後開成熟答案仍7/10。

所以7/10不是從成熟權回推shift得到，而是：

> **古籍A獨立給operator × 古籍B獨立給carrier row → 成熟表validation 7/10。**

## 九、證據等級

- WYG卷一operator：**DIRECT TEXT**
- 《紫微數》固定祿row：**DIRECT TEXT / ESTABLISHED EARLY ROW**
- operator × Lu row生成Q0：**LOW-FREEDOM RECONSTRUCTION**
- Q0對成熟權7/10：**VALIDATION**
- 乙壬癸重掛規則：本節尚未加入
- 816是否必要：**PENDING NEXT ABLATION**
- 明刻十八卷是否已有同operator／同混合層：**VERSION-TIME PENDING**

## 十、結論

前面指定的前三步現在已完成：

1. WYG完整十曜／十一曜框架與功能矩陣：完成；
2. 卷一總公式 vs 單曜章一致性、異常群與負控：完成；
3. 《星學大成》general祿→權operator接《紫微數》固定祿row：完成。

而結果不是倒退，反而把既有7/10骨架重新建立成更乾淨的target-free鏈：

> WYG卷一【權(g)=祿(g−1)】  
> ×《紫微數》固定祿row  
> → Q0 先生成  
> → 成熟權開答案後7/10  
> → 只剩乙、壬、癸。

下一步才重新開乙壬癸殘差，嚴格測：

> 拿掉816後，現有古籍內是否存在更簡單、同樣target-free的selector；若沒有，816才升格為minimal necessary rule。
