# §750 化權封板後最終 provenance／status matrix：公式、古法元件、作者採用句、版本時間層四層分離

日期：2026-10-05

## 一、目的

§743曾把化權歷史主線封板；§744–§749又補了兩個重要變化：

1. 1581《捷覽》PT31–PT32原彩影印已直接取得，安星逆行與成熟四化／乙權天梁由轉錄級升為原頁anchor；
2. 尊經閣隆慶本兩個功能列已壓縮成外部原件問題，官方研究／複製洽詢路徑亦已核，版本支線正式進入 AWAITING_EXTERNAL_WITNESS。

因此需要重新做一次總分層，避免今後把不同層級混成「公式到底有沒有證明」。

可重跑：

`research/four_hua_20260929/quan_750_final_provenance_status_matrix_20261005.js`

## 二、最終矩陣

| 層 | 現況 | 可以寫 | 不能寫 |
|---|---|---|---|
| ALG | **CLOSED** | 成熟化權重建算法在既定成熟表上10/10閉合；target-free selector、消融、跨版本穩健性已完成 | 因此1581編者明文使用8→1→6 |
| VAL | **CLOSED** | 1581成熟化權表本身validation＝10/10 | 所有版本時間層均已確定 |
| PRIM | **SUBSTANTIALLY CLOSED** | 祿anchor、十變operator、fixed-carrier re-tagging、北極scope、紫微逆行、cycle、816成組等已有直接或同型古法來源 | 古人已明說把這些primitive串成成熟化權 |
| POOL | **RECONSTRUCTED** | 廉退紫入被古名、帝座／主宰、化囚與結構約束壓到低自由度 | 已找到編表者自述廉退紫入理由 |
| C1 | **DIRECT CONNECTOR NOT FOUND** | fixed Lu row與ten-bian Quan offset兩邊的primitive都存在，checked corpus仍未見specific adoption句 | C1已由古文直接證成 |
| C2 | **DIRECT CONNECTOR NOT FOUND；原頁鄰近性升級** | PT31–PT32已把紫微逆行與成熟四化／乙權天梁升為1581原彩原頁相鄰域 | 原頁相鄰就等於generator自述 |
| VERSION_TIME | **AWAITING EXTERNAL WITNESS** | 隆慶兩行只待原影／人工校讀，且只重定級§719–§723版本時間層 | 因兩行未回而把ALG／VAL重新降級 |

## 三、公式成立與歷史自述必須分開

目前最容易犯的錯是把：

> 「我們沒有找到編表者一句話說他用了8→1→6」

錯寫成：

> 「8→1→6公式沒有證據」。

這兩句完全不同。

### 算法層

目前可以穩定寫：

> **成熟化權10/10重建已完成。**

原因不是單純「剛好擬合」，而是既有研究已做：

- target-free selector；
- 消融；
- 跨版本穩健性；
- 權科洛書線正控；
- 北方anchor→坎一 selector；
- 古名反證過濾；
- 成熟表十干validation。

這一層已封。

### 歷史primitive層

可以寫：

> **重建需要的大部分古法operation primitive已有直接或同型歷史來源。**

包含：

- 固定星祿row；
- 從祿anchor取role；
- 十變曜位次；
- 十變ontology映入固定星；
- fixed carrier接受動態生年tag；
- 北極／亥子丑scope；
- 紫微逆行；
- 稀疏跳位後回首；
- 九宮816成組與方向；
- 局部三位化曜先例。

故不應再泛搜「古人會不會這種算法」。

### composition provenance層

真正未閉合的是：

- C1：fixed Lu row → ten-bian Quan offset；
- C2：north-three／紫微逆行 → 乙壬癸成熟權殘差。

也就是：

> **缺的是古代編表者說「我正是這樣串起來」的specific adoption句，不是缺所有古法元件。**

## 四、§746對C2究竟提升了多少

1581《捷覽》PT31–PT32原彩頁取得後，C2的歷史證據確實比§743時更強：

### §743以前
主要依：
- 點校／轉錄；
- 同卷章序；
- 結構對照。

### §746以後
已直接得到：
- PT31：紫微天機逆行原頁；
- PT32：成熟四化與【天梁下安化權】worked example原頁；
- 兩者屬同一1581底本的緊鄰頁域。

因此可以把：

> 「安星operator與成熟四化只是後人整理時看起來相鄰」

這個疑慮大幅排除。

但原頁仍沒有直接出現：

- 依前法；
- 主星若動而權隨；
- 北極三位取權；
- 乙壬癸依三位輪轉；
- 8→1→6；
- 其他明確generator接句。

所以C2必須維持：

> **原頁鄰近性很強，specific composition direct仍未出土。**

## 五、隆慶本兩行不得拖低主公式

尊經閣隆慶本的紫炁／計都結果，真正影響的是：

> §719–§723「角色掛名混合剖面究竟何時形成」。

它可能回答：

- 舊掛名是否已存在於1567–1572；
- 隆慶本是否已完成萬氏新權正規化；
- 是否存在前1581逐曜非同步更新。

但無論結果是：

- 己／庚；
- 壬／癸；
- 混合；
- 第三異文；

都不會自動推翻：

- 成熟權10/10；
- §720宋天福slot＝萬氏天權slot；
- §721宋福投影特異性；
- 8→1→6重建鏈。

所以§749把它改成 AWAITING_EXTERNAL_WITNESS 是正確的邊界管理，而不是研究退步。

## 六、今後統一用語

### 建議使用

> **成熟化權算法已10/10閉合；其所需古法primitive provenance已近閉合。1581《捷覽》原彩頁又直接確認紫微逆行與成熟四化／乙權天梁同在相鄰原頁域。目前尚未出土的是C1、C2兩條specific composition adoption句；另有隆慶本兩行等待外部原影，只影響版本時間層。**

### 不再使用

> 「化權公式還沒有古文證明。」

因為這會把：
- 公式validation；
- primitive來源；
- 作者採用自述；
- 版本年代；

四個不同問題混成一個。

## 七、研究狀態

截至§750：

> **ALG = CLOSED**  
> **VAL = CLOSED**  
> **PRIM = SUBSTANTIALLY CLOSED**  
> **POOL = RECONSTRUCTED**  
> **C1 = DIRECT CONNECTOR NOT FOUND**  
> **C2 = DIRECT CONNECTOR NOT FOUND，original-page adjacency upgraded**  
> **VERSION_TIME = AWAITING_EXTERNAL_WITNESS**

這是目前最適合直接拿去寫研究文章的總狀態。

## 八、下一步

主線下一步不應再擴大搜尋。

若目標是繼續研究，只有兩種高信息量事件值得重開：

1. **新原件事件**：C1／C2 direct connector、隆慶兩行、1581高解析小註；
2. **成文事件**：依§750矩陣開始整理化權重建正式文章／HTML，把「已證」「重建」「待原件」用固定標籤分開。

也就是說，§750之後化權研究本身已適合進入**成文封板階段**；外部新史料到了再局部重開。
