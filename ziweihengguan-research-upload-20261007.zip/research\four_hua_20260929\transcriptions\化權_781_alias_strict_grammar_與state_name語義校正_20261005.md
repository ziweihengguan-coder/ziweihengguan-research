# 化權 §781｜blind alias strict grammar 與 state-name 語義校正

日期：2026-10-05

## 一、目的

§779–780 已證明：在不使用816、不預設乙壬癸、不提供成熟化權位置的情況下，WYG general operator + 廉退紫入 pool + WYG單曜命名詞彙 + 同干四化不重，可以唯一得到成熟化權10/10。

本節只做兩件事：

1. 排除 §779 broad line-level naming grammar 的假命中，確認唯一解不是由「同列共現」或複合詞造成。
2. 對三條 critical bridge 做語義類型審計，區分：
   - physical identity / global name
   - 躔宿 state-name
   - 變段 state-name
   - 跨文本同名 lexical reachability

本節不新增第三套 selector，也不把演算法唯一性直接等同歷史採用。

---

## 二、STRICT grammar 重跑

§779 原 broad grammar：

- 一名
- 又名
- 號
- 名為
- 名曰
- 元來是
- 原來是
- 謂之

原版做法是：只要一行含 naming marker，就收該行所有已知古名 token。

這會產生兩類噪音：

1. 月章「太陰……一名莫星」：太陰只是同列主體，不是 marker 後真正被命名的對象。
2. 「紫微垣」「天府官」：token 本身出現，但實際是複合專名，不宜直接當固定星 alias。

所以本輪把 grammar 收緊：

- 號／名為／名曰／元來是／原來是／謂之：
  只收 marker 後真正開始的 named token。
- 又名／一名：
  收 marker 後 named token；若 marker 前明確是「X星○又名」，也收 X 作雙向等名。
- 排除「紫微垣」「天府官」等 compound suffix。

### 結果

BROAD：
- candidates = 9,216
- pool pass = 2
- row pass = 53
- pool + row = 1
- unique solution = mature Quan 10/10

STRICT：
- candidates = 2,304
- pool pass = 2
- row pass = 14
- pool + row = 1
- unique solution = mature Quan 10/10

唯一解沒有改變：

【甲破、乙梁、丙機、丁同、戊陰、己貪、庚武、辛陽、壬紫、癸巨】

因此 §779 的唯一性不是由：
- 太陰同列假命中
- 紫微垣
- 天府官
等 broad leakage 造成。

更新腳本：
- `research/four_hua_20260929/quan_779_blind_wyg_old_name_universe_audit_20261005.js`
- methodVersion：`2026-10-05-blind-wyg-old-name-universe-v2-strict-broad`

---

## 三、三條 critical bridge 的語義類型其實不同

### B1：火 → 天梁

WYG 火星章先明題：

> 火星躔宿俱出玉關經玉關歌

其後：

> 火躔房宿號天梁

所以這不是「火星＝天梁」的無條件 physical identity。

它是：

【火星 × 房宿 state → 號天梁】

定級：

**MANSION_DEPENDENT_STATE_NAME**

同章還有：
- 火躔心宿號天相
- 火躔軫宿號天暴
- 獅子宮火星號天雷
等，證明這是一整套狀態命名系統。

### B2：炁 → 紫微

WYG 紫炁章：

> 此曜元來是紫㣲

這一句不依賴特定宿位／宮位，語氣也不是「某段號某星」。

目前三橋中，它最接近：

**IDENTITY_LIKE_GLOBAL_NAME**

所以 B2 歷史強度仍為三者最強。

### B3：計 → 白衣 → 巨門

WYG 計都章明題：

> 計都變段星

其後：

> 巨獬宫白衣星○又名天孛星

因此第一跳不是：

【計都＝白衣】

而是：

【計都 × 巨蟹／巨獬變段 state → 白衣星】

定級：

**ZODIAC_SEGMENT_STATE_NAME**

第二跳來自早期紫微文本：

- 本機人工校讀：白衣＝巨門
- §731 同系公開轉錄：白衣＝孛星＝巨門

但同一早期紫微傳統又同時寫：

- 天暴＝計都星＝廉貞

也就是說：

【白衣】在《紫微數》字面曜體身分偏向孛，
而【計都】在《紫微數》字面曜體身分反而連到天暴／廉貞。

因此：

> WYG「計都變段名白衣」＋《紫微數》「白衣＝孛／巨門」  
> 不能當成同一 physical body 的傳遞式 identity。

它只能證：

**contextual lexical/name reachability**

而不是：

**transitive body identity**

---

## 四、B3 同名碰撞的精確表示

WYG：

【計都 →（巨蟹變段名）→ 白衣】

早期《紫微數》：

【白衣 → 孛星 → 巨門】

同一《紫微數》對計都：

【計都 → 天暴 → 廉貞】

所以「白衣」是兩套命名系統相交的一個 lexical token，
但其 physical-body 指涉並不相同。

這是目前 Route B 最重要的語義校正。

---

## 五、identity-only 負控

新增審計：

`research/four_hua_20260929/quan_781_state_name_semantic_type_audit_20261005.js`

只保留三橋中最接近 global identity 的 B2：

【炁 → 紫微】

把 B1、B3 兩條 state-name transfer 全部拿掉。

結果：

- full three-bridge lexical route：pool+row = 1，最後 10/10
- identity-like only：pool+row = 0

因此 Route B 的成熟10/10，**必須依賴 contextual state-name transfer**。

它不是只靠 direct synonym / physical identity 就能閉合。

---

## 六、這不推翻 §779–780 的演算法結果，但改變歷史定級

### 演算法層仍成立

在事前固定來源 universe + naming grammar + pool + row constraints 下：

- BROAD 唯一10/10
- STRICT 仍唯一10/10

所以 target-free computational identifiability 沒有消失。

### 歷史層必須降級

原先「alias selector」容易讓人誤讀成：

【某曜的別名就是某固定星】

這不精確。

後續正式用語改成：

**CONTEXTUAL NAME-REACHABILITY SELECTOR**

或：

**STATE-NAME LEXICAL SELECTOR**

證據等級：

- computational：
  **TARGET-FREE / SOURCE-BOUNDED / UNIQUE 10/10**
- historical mechanism：
  **RECONSTRUCTED / SEMANTIC TRANSFER NOT DIRECTLY ATTESTED**

---

## 七、外部精確搜尋結果

本輪另用公開可檢索古籍做精確搜尋：

- 「計都 巨門」
- 「計都 白衣星 巨門」
- 「白衣星 巨門」
- 「白衣 月孛 巨門」
- 「天暴 計都 廉貞」

可直接核到的《星學大成》卷二十二仍只支持：

- 計都為天尾星
- 計都章內有「計都變段星」
- 巨蟹／巨獬變段出「白衣星」

目前沒有找到一條更直接的古文寫：

【計都＝巨門】

或：

【計都之白衣即巨門】

所以 B3 一跳直證目前仍未出土。

---

## 八、§781 後的最新判斷

§780 的「三橋共同充分、各自必要」仍是演算法事實。

但三橋歷史語義排序要改得更精確：

1. B2 炁→紫微  
   最強，接近 global identity-like name。

2. B1 火→天梁  
   次強，但其實是「火躔房宿」的 state-name。

3. B3 計→白衣→巨門  
   最弱；不只是跨兩文本二跳，還存在明確 literal-body semantic mismatch。

因此 Route B 現在最準確的完整描述是：

【WYG祿前移 → Q0 → 廉退紫入 → contextual name-reachability（含火房宿號天梁、炁元來是紫微、計都巨蟹變段名白衣 × 紫微數白衣→巨門） → pool守恆 → 同干去重 → mature Quan 10/10】

不是：

【十變曜 physical alias 直接翻成成熟固定星】

---

## 九、下一步

若繼續歷史直證，第一順位應改成：

1. 找古本直接說明「變段名／躔宿號名」可以被跨系統拿去當固定星 carrier 名。
2. 專找同一文本內把「計都白衣」與「巨門」接起來的句子。
3. 若找不到，Route B 就維持「target-free computational lexical selector」，不再把它往 direct historical operator 上推。
4. 幾何 Route A（816）仍作另一條獨立 reconstruction，不受本節 semantic-type 校正推翻。

§781 核心結論：

> **§779–780 的blind唯一10/10沒有被反證；真正被校正的是「alias」的歷史語義。B1、B3其實是context-dependent state-name，尤其B3還與《紫微數》的literal body mapping衝突。因此Route B應改稱contextual name-reachability selector：計算上唯一，歷史上仍是語義轉移重建，而不是古文直接的曜體同一。**
