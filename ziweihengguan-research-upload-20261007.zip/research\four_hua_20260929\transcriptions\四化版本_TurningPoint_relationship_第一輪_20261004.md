# Variant-aware Turning Point｜第一輪 Liang relationship 實測

更新：2026-10-04  
對應研究紀錄：§699

## 一、目的

§698 已確立正確整合層級：

【event/timing rule】
→【variant-aware transformation evidence】
→【condition judgement】
→【candidate status】
→【版本差異輸出】

本輪只做研究 wrapper：

- 不修改正式 knowledge['stem']；
- 不改 Turning Point event rules；
- 不改 condition weights；
- 不改 UI；
- 只對五個已見 profile 覆寫：
  - 庚化科；
  - 庚化忌；
  - 壬化科；
- 第一輪只跑 liang_feixing；
- 只測目前 enabled 的兩個 relationship event：
  - important_relationship_development；
  - relationship_household_commitment。

## 二、Wrapper 只替換三類真正帶四化版本的 context

Relationship rules盤點後，candidate status會受四化版本直接影響的主要結構是：

1. trace.timeline.decade.transformations；
2. trace.timeline.annual.steppedTransformations；
3. roleFlightMatrix 的 natal／decade／annual 宮干飛化。

Liang profile 的 annual year-stem 本來就被 time profile 排除，因此不把它混進 candidate。

本命 relationship foundation 與鸞喜研究支援維持原正式邏輯。

## 三、必要正控：G0R0 必須等於正式網站底表

本站現行底表就是 G0R0。

因此研究 wrapper 若正確，G0R0 結果必須和正式：

【zh_build_turning_point_timeline + liang_feixing】

一致。

已核三組：

### D1 1972-08-13寅女｜1998
正式：
- important relationship＝candidate；
- household commitment＝candidate。

wrapper G0R0：
- 完全相同。

### H1 1977-05-16午男｜2004
正式：
- important relationship＝candidate；
- household commitment＝not_established；
- household 失敗條件＝relationship_household_commitment_link。

wrapper G0R0：
- 完全相同。

### 同盤｜2005
正式：
- important relationship＝not_established；
- failed＝relationship_annual_direct_activation；
- household 同時缺 annual direct＋household link。

wrapper G0R0：
- 完全相同。

因此第一輪 base parity 通過。

## 四、V0～V2正式可執行

### V0
五版 candidate status相同，witness route亦相同。

### V1
五版 candidate status相同，但 witness route不同。

### V2
五版 candidate status本身不同。

這次已經實際跑出三類中的 V0、V1、V2，不再只是架構設計。

## 五、6個已知 relationship event-year：目前只有 V0／V1，沒有 V2

### D1 1972女｜1998登記＋婚禮

important relationship：
【V0，五版全 candidate】

household commitment：
【V0，五版全 candidate】

這表示：
這個已知婚例的 Turning Point 成立完全不依賴 G/R 異文。

### H1 1977男｜2004註冊結婚

important relationship：
【V0，五版全 candidate】

household commitment：
【V0，五版全 not_established】

五版都卡在：
【relationship_household_commitment_link】

所以：

> 換四化版本不會修掉 H1 2004 的 household-form MISS。

問題在事件 form 規則／coverage，不在 G/R 表。

### H1 1977男｜2005婚姻／公婆衝突危機

important relationship：
【V0，五版全 not_established】

全部卡：
【relationship_annual_direct_activation】

因此版本差異也不會把這個已知危機年變成目前 broad relationship candidate。

### S1 1980女｜2004結婚

important relationship：
【V0，五版全 not_established】

同樣是 annual direct activation 不成立。

所以 §693 已知的 S1 MISS 不能靠換 G/R 表修正。

### S2 1965男｜2005離婚

important relationship：
【V1，五版全 candidate】

但 witness route 分成 3 種。

household commitment：
【V1，五版全 not_established】

所以這一例版本差異真正影響：

【候選成立後，作用路徑怎麼解釋】

而不是：
【有沒有候選】。

### S3 1971女｜2005離婚

important relationship：
【V1，五版全 candidate】

witness route 分成 2 種。

household commitment：
【V1，五版全 not_established】

同樣屬：

【status invariant / route sensitive】。

## 六、已知 relationship event-year 統計

important_relationship_development：

- V0＝4；
- V1＝2；
- V2＝0。

relationship_household_commitment：

- V0＝4；
- V1＝2；
- V2＝0。

所以目前最重要的新結果是：

> 在這6個已知relationship event-year裡，四化版本異文尚未改變任何 candidate / not_established 結果。

它只在 S2／S3 兩個離婚年改變 witness route。

這和 §693～697 的結論高度一致：

【版本差異多數是路由層，不等於事件成立層。】

## 七、但 V2 在結構上確實存在

為了確認 wrapper 不是因規則太粗而永遠只能 V0/V1，本輪掃了 S3 1971女的其他年份。

### 1998

important relationship：

- G0R0＝candidate
- G0R1＝candidate
- G1R0＝not_established
- G1R1＝not_established
- G2R1＝candidate

G1兩版失敗條件：

【relationship_annual_direct_activation】

這是實際的：

【V2／G-only candidate-status sensitivity】

因此古本異文確實可以一路傳到正式 event judgement。

不是只能改解釋文字。

## 八、1998 V2不能拿來說哪版較準

S3 1971女的已知資料中：

1998是：
【生第一胎】

本輪跑的是：
【important_relationship_development】

不是 childbirth event rule。

因此1998只能當：

【candidate-status V2 結構正控】

不能拿來說：
- G0較準；
- G2較準；
- G1漏掉婚姻。

Ground truth domain不對。

這個界線必須保留。

## 九、目前沒有看到 R-only candidate-status V2

第一輪已知事件與目前掃描中：

- G 模組已明確能造成 V2；
- R0／R1已能造成路徑差異；
- 但還沒找到「只因R0/R1不同就使candidate status分裂」的乾淨 V2。

所以目前不能說：
【壬左輔／天府差異會常改事件成立】。

下一輪應做更大範圍 census 才能回答。

## 十、§699真正重要的新結論

### 1. 四化版本真的能穿透到事件 judgement
V2已存在。

### 2. 但已知 relationship event-year 暫時沒有 V2
所以目前沒有證據說改古表版本能提高這批已知感情事件召回。

### 3. 現有 household-form MISS 不是版本問題
H1 2004、S1 2004等跨五版仍 miss。

### 4. V1才是目前已知事件中的主要版本效應
即：
【事件候選不變，路徑不同】。

### 5. 必須分兩種資料集
- known-event validation；
- all-year structural census。

不能把一般年份V2直接算成某版本「預測成功」。

## 十一、下一步 §700

做 V0／V1／V2 全年份 census。

第一輪先用目前完整的 relationship 命盤：
- D1 1972女；
- H1 1977男；
- S1 1980女；
- S2 1965男；
- S3 1971女。

對每盤固定成人年份窗。

統計：
1. important relationship 的 V0/V1/V2 年份量；
2. household commitment 的 V0/V1/V2；
3. V2分成 G-only、R-only、G×R；
4. candidate status pattern；
5. known-event年份另標記，但不混入全年份頻率；
6. 檢查 V2是否只集中在庚／壬相關宮干／時間結構。

## 十二、可重跑材料

- research/four_hua_20260929/four_hua_variant_turning_point_probe_20261004.php
- research/four_hua_20260929/four_hua_chart_fixture_emit_20261004.js
- research/four_hua_20260929/four_hua_turning_point_canonical_liang_probe_20261004.php
- research/four_hua_20260929/four_hua_variant_turning_point_summarize_20261004.js
- research/four_hua_20260929/four_hua_variant_turning_point_stage1_20261004.results.json
- research/four_hua_20260929/transcriptions/四化版本_TurningPoint_relationship_第一輪_20261004.md
