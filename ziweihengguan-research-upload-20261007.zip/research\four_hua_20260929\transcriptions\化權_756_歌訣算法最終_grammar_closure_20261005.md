# §756 歌訣算法最終 grammar closure：10/10最小鏈已無「必須現代新發明」的operator（2026-10-05）

## 一、目的

§751–755沿「古訣＝可執行算法」重讀後，已依次得到：

- §751：廉退紫入可壓成【古文先選紫微主宰→紫微六星環自動給廉貞前驅→廉→紫wrap】；
- §752：古代斗數的多段composition、換anchor、換scope、換方向直接有明文；
- §754：北極scope＋紫微逆行唯一推出8→1→6；carrier三星序是同文本內生誘導，不冒充直接三字訣；
- §755：skip／保序／稀疏取項／wrap均為古法直接grammar。

本節把所有新證據回灌最小10/10模型，回答：

> 整條生成鏈是否還存在任何一個「沒有古法operator先例、只能由2026研究者新發明」的操作？

新增並實跑：
- `research/four_hua_20260929/quan_756_song_formula_final_grammar_closure_audit_20261005.js`

結果：

> **unsupportedGenericGrammarCount = 0**

---

## 二、最小生成鏈

### Step 1：C1 global shift

早期固定星祿row：

| 干 | 祿 |
|---|---|
| 甲 | 廉貞 |
| 乙 | 天機 |
| 丙 | 天同 |
| 丁 | 太陰 |
| 戊 | 貪狼 |
| 己 | 武曲 |
| 庚 | 太陽 |
| 辛 | 巨門 |
| 壬 | 天梁 |
| 癸 | 破軍 |

依十變曜【權relative to祿】的循環offset，把carrier沿十干環前進一位：

> 甲破、乙廉、丙機、丁同、戊陰、己貪、庚武、辛陽、壬巨、癸梁

Q0 validation＝7/10。

generic grammar：
- 祿作anchor；
- 移動起點；
- 平行有序row；
- 由功能位次取同位carrier。

古法直接見證：
1563十變曜可執行例。

specific adoption仍屬重建：
> 把十變曜權offset特定套到固定星祿row。

---

## 三、Step 2：POOL normalize現在不是任意replace

§751已證：

紫微六星古訣閉環：

> 紫微→天機→太陽→武曲→天同→廉貞→紫微

古文角色又先選：

> 紫微＝北斗之主宰／群宿眾星之主

一旦新增carrier由角色先選紫微，其古典前驅自動是廉貞：

> 廉貞→紫微

故Q0：

> 甲破、乙廉、丙機、丁同、戊陰、己貪、庚武、辛陽、壬巨、癸梁

normalize成：

> 甲破、乙紫、丙機、丁同、戊陰、己貪、庚武、辛陽、壬巨、癸梁

仍7/10。

generic grammar：
- sovereign/master selector；
- ordered star cycle；
- wrap to anchor。

均有古法直接見證。

specific adoption仍屬重建：
> 編表者是否真的以這組主宰＋wrap作權pool normalization。

---

## 四、Step 3：C2 scope

前1581星命已直接把北極操作成：

> 亥－子－丑

《捷覽》自身又明列：

> 亥子丑三宮屬水。

所以北極局部scope：

> {亥,子,丑}

不再是洛書8條線中人工挑一條。

generic grammar：
- north-pole local scope；
- three-place grouping。

直接古法來源已存在。

specific adoption：
> 是否把此scope特定施於成熟權前態。

---

## 五、Step 4：C2 orientation

正常十二支北側：

> 亥→子→丑

《捷覽》紫微系明文：

> 紫微天機星逆行。

所以北scope取反向：

> 丑→子→亥

九宮方位：

> 丑8→子1→亥6

即：

> **8→1→6**

再由既定天干數對應：

> **乙→壬→癸**

generic grammar：
- reverse direction；
- ordered ring traversal。

直接古法見證：
《捷覽》紫微系逆行。

specific adoption：
> 是否把紫微安星direction特定沿用到權pool。

---

## 六、Step 5：局部group remount

Step 2後三個北scope干位：

- 乙＝紫微
- 壬＝巨門
- 癸＝天梁

沿【乙→壬→癸】局部閉環讓carrier前進一位：

- 乙紫 → 壬
- 壬巨 → 癸
- 癸梁 → 乙

得到：

| 干 | 成熟權 |
|---|---|
| 甲 | 破軍 |
| 乙 | 天梁 |
| 丙 | 天機 |
| 丁 | 天同 |
| 戊 | 太陰 |
| 己 | 貪狼 |
| 庚 | 武曲 |
| 辛 | 太陽 |
| 壬 | 紫微 |
| 癸 | 巨門 |

validation：

> **10/10**

generic grammar：
- group movement；
- previous output as next-stage input；
- nested composition；
- closed cycle／wrap。

古法見證：
- 《捷覽》「主星若動則眾星奔馳」；
- 紫微／天府anchor平移帶整組；
- 《全書》斗君、金鎖鐵蛇多段composition。

specific adoption：
> 是否把這個group-remount特定用在成熟權三carrier。

---

## 七、最終消融

### 無C1

直接從祿row起，再作紫入與北scope local cycle：

> mature match = 0/10

所以C1是生成必要。

### 無POOL normalize

保留廉貞，再作同一北scope cycle：

> mature match = 9/10

只差壬廉應為壬紫。

所以POOL normalize是最後1格必要修正，不是裝飾。

### 無C2 local cycle

停在pool-normalized base：

> mature match = 7/10

所以C2是3格殘差的必要操作。

### C2改相反方向

同scope但用反向cycle：

> mature match = 7/10

所以orientation不是任意。

---

## 八、一個重要簡化：§755 projection不是最小生成必要步驟

§755證：

> skip／保序／sparse subsequence／wrap皆為古法grammar。

這對歷史可行性很重要。

但§756重新做最小鏈後發現：

> 一旦北極scope已直接鎖定乙、壬、癸，三個carrier已經各自在這三slot上；只需要把整個group沿乙→壬→癸局部cycle移動，即可10/10。

因此不必另外增加：

> 「先把紫、巨、梁從完整主星序投影出來」

作為生成primitive。

所以§755應降為：

> **supportive grammar，非最小鏈必要operation。**

這反而讓模型更簡單。

---

## 九、最終grammar矩陣

| 階段 | 操作 | generic古法grammar | specific mature-Quan adoption |
|---|---|---|---|
| C1 | 祿row沿十干環前進一位 | DIRECT | RECONSTRUCTED |
| POOL | 紫微主宰＋廉→紫wrap | DIRECT | RECONSTRUCTED |
| C2 scope | 北極亥子丑 | DIRECT | RECONSTRUCTED |
| C2 direction | 紫微逆行→816 | DIRECT | RECONSTRUCTED |
| C2 remount | 三carrier整組閉環前進 | DIRECT / same-type | RECONSTRUCTED |

因此：

> **unsupported generic operator grammar = 0**

---

## 十、§756後最準確的歷史定級

### ALG
**CLOSED 10/10**

### GENERIC OPERATOR GRAMMAR
**CLOSED**

成熟權最小鏈所使用的每一種抽象operation，在古代斗數／同時代星命中都已有直接或同型可執行先例。

目前不存在：

> 「為了湊出成熟權，必須發明一種古書從未使用過的算法操作。」

### SPECIFIC ADOPTION
**NOT DIRECTLY STATED**

尚未直證的不是算法語法，而是編表史：

1. C1：編表者是否把十變曜權offset套到固定星祿row；
2. POOL：是否用紫微主宰＋廉→紫wrap正規化權pool；
3. C2：是否把北極亥子丑＋紫微逆行＋group remount套到權前態。

這三項其實可再上收為一句：

> **mature-Quan-specific composition/adoption statement 未出土。**

---

## 十一、今天這條新主線的真正成果

原本§750：

> primitive近閉合，但仍有specific composition gap。

§751–756之後可以改成：

> **算法10/10閉合；所有必需generic operator grammar均可落回古訣／古法；沒有任何生成步驟需要一種現代新發明的操作。唯一未直證的是編表者選擇把這些古法operator特定組成成熟化權的歷史採用關係。**

這比「找到一條長得像公式的古文」更強，也更符合古代術數實際寫法：

> 公式被分散保存為多首可執行歌訣，而不是以現代代數式集中說明。

## 十二、下一步

主線不宜再泛搜operator。

接下來若繼續攻歷史層，只做兩種高價值工作：

1. **composition adjacency／章序研究**  
   檢查《捷覽》《全書》為何把祿存、羊陀、火鈴、四化、紫府安星等訣按現在次序編排，是否章序本身就是「先算A再算B」的instruction chain。

2. **同書 worked-example dataflow**  
   不搜抽象詞，而逐例追古書是否把前一訣算出的宮位／星位直接拿給下一訣使用；若四化附近也存在這種dataflow，可再逼近specific adoption。

否則可正式進入成文：
- 【算法公式】
- 【逐步古訣來源】
- 【何者直接、何者重建】
- 【唯一剩餘歷史缺口】
四層分開。
