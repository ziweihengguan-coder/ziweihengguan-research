# §752 全歌訣 operator census：古代斗數的多段算法 composition 已直接成立（2026-10-05）

## 一、目的

承接§751，「歌訣＝算法」已使原本五步化權鏈壓縮為三個有序閉環上的 successor／wrap 文法。

本節不再找某一句「化權原訣」，而做更嚴格的語法普查：

> 化權重建所需的 anchor、direction、relative offset、remount、wrap、sparse cycle、前段輸出作後段anchor、scope switch、direction switch、nested composition、group movement，是否都能在古代斗數／同時代星命文本中找到直接可執行先例？

新增並實跑：

- `research/four_hua_20260929/quan_752_executable_song_operator_census_20261005.js`

結果：
- 見證：11組；
- 抽象operator：25種；
- 化權重建必需語法11類：11/11均有古法見證；
- 古代多段composition最大深度：至少4段。

---

## 二、十一組核心古訣見證

### 1. 1563《星學大成》十變曜

操作語法：

【生年干決定祿起點】
→【從祿數至欲求功能】
→【在平行曜序取同位】
→【餘依此推】

對應operator：
- ANCHOR
- MOVING_START
- ORDERED_PARALLEL_ROWS
- ORDINAL_COUNT
- REPEAT

這是C1全域「祿→權」operator最直接的前1581星命見證。

### 2. 乙亥字《紫微數》：「一法從祿上」

> 一法從祿上，如前女逆男順。

operator：
- ANCHOR
- DIRECTION_BY_POLARITY
- ORDERED_SEQUENCE

證祿可以直接作派生其他角色的起點。

### 3. 《紫微數》正祿前後掃火／烈神

> 正祿在寅，掃火在卯，烈神在丑，前後擁遮。

operator：
- ANCHOR
- RELATIVE_OFFSET
- BIDIRECTIONAL_WINGS
- REMOUNT

證同一anchor可向前後相對重掛其他角色。

### 4. 明刊《全書》羊陀

> 此二星隨祿存安之，祿前安羊，祿後安陀羅……餘做此。

operator：
- ANCHOR
- RELATIVE_OFFSET
- REMOUNT
- REPEAT

而且它就位在成熟四化訣前的安星程序序列內。

### 5. 明刊《全書》斗君

> 於流年太歲宮起正月逆至本生月，又從本生月起子順數至本生時安斗君。

這段非常重要，因為它不是單步公式，而是：

【太歲宮作anchor】
→【逆數到生月】
→【把上一步所得宮位直接當下一段anchor】
→【改用順數】
→【數到生時】

operator：
- ANCHOR
- DIRECTION
- OUTPUT_AS_NEXT_ANCHOR
- SCOPE_SWITCH
- DIRECTION_SWITCH
- NESTED_COMPOSITION

至少2段composition直接成立。

### 6. 明刊《全書》金鎖鐵蛇關

古訣／解文依次：

【戌起生年】
→【順】
→【年上起月】
→【逆】
→【月上起日】
→【再換方向】
→【日上起時】

operator：
- ANCHOR
- OUTPUT_AS_NEXT_ANCHOR
- SCOPE_SWITCH
- DIRECTION_SWITCH
- NESTED_COMPOSITION
- REPEAT

這至少構成4段串接。

因此古代斗數不是只會單一歌訣公式；「前一段輸出作下一段起點＋中途換scope／換方向」本身就是明文存在的正常算法。

### 7. 明刊《全書》五行局安紫微

金、木、水、火、土局歌訣直接使用：
- 順進；
- 逆退；
- 逆進；
- 順回；
- 固定步數；
- 特例回轉。

operator：
- DIRECTION
- STEP_SIZE
- DIRECTION_SWITCH
- LOCAL_STEP_RULE
- RETURN

證「數值步進＋方向切換」會直接壓成韻訣。

### 8. 1581《捷覽》紫微六星

> 紫微天機星逆行……又隔二位廉貞位，空三便是紫微星。

operator：
- ANCHOR
- DIRECTION
- SKIP
- ORDERED_SEQUENCE
- WRAP
- SPARSE_CYCLE

這也是§751「廉貞→紫微」的直接閉環來源。

### 9. 1581《捷覽》主星帶群

> 紫微，北斗之主宰……主星若動則眾星奔馳。

operator：
- SOVEREIGN_ANCHOR
- GROUP_MOVE
- EQUIVARIANCE

配合卷一安星公式，可確認不是純修辭，而是anchor變動帶動整組星位的實際資料結構。

### 10. 明刊《全書》紅鸞／天喜

先依年支逆數取得紅鸞，再以其對宮定天喜。

operator：
- ANCHOR
- DIRECTION
- OUTPUT_AS_NEXT_ANCHOR
- OPPOSITE
- REMOUNT

證「先算A，再以A的幾何關係生成B」。

### 11. 明刊《全書》喪門／白虎／吊客／官府

以太歲為anchor：
- 前二＝喪門；
- 後二＝吊客；
- 喪門對宮＝白虎；
- 吊客對宮＝官府。

operator：
- ANCHOR
- RELATIVE_OFFSET
- BIDIRECTIONAL_WINGS
- OUTPUT_AS_NEXT_ANCHOR
- OPPOSITE
- REMOUNT

這是另一個「局部先生成兩點，再由兩點生成第二層角色」的直接例。

---

## 三、化權所需11類語法全部有古法先例

腳本要求：

1. ANCHOR
2. DIRECTION
3. RELATIVE_OFFSET
4. REMOUNT
5. WRAP
6. SPARSE_CYCLE
7. OUTPUT_AS_NEXT_ANCHOR
8. SCOPE_SWITCH
9. DIRECTION_SWITCH
10. NESTED_COMPOSITION
11. GROUP_MOVE

實跑：

> allRequiredGrammarWitnessed = true

也就是：

> 化權重建中沒有哪一類抽象操作，是古代斗數／同時代星命完全未見、只能由現代研究者新發明的。

這不等於已證編表者採用本研究的完整composition，但已排除一個更強的反對可能：

> 「這種多段anchor、局部重掛、換方向、回首的算法不像古代斗數。」

實際文本正相反：這就是古代斗數常用的算法語言。

---

## 四、最大的新歷史收斂：composition grammar 本身可以封板

此前C1／C2被稱作 composition provenance gap，容易讓人誤解成：

> 缺的是古代是否存在這種把多個operator串起來的能力／文法。

§752後這個問題可以正式關閉。

### Generic composition grammar

狀態：

> **CLOSED / DIRECTLY WITNESSED**

理由：
- 斗君＝至少2段；
- 金鎖鐵蛇＝至少4段；
- 紅鸞→天喜、喪門→白虎等又直接使用前段輸出作後段anchor；
- 中途換順逆、換作用域、用對宮、前後位與回首均有直接文本先例。

### Specific Quan composition

狀態仍為：

> **RECONSTRUCTED, NOT DIRECTLY STATED**

真正剩下的歷史問題只剩：

> 編表者是否真的把「十變權operator＋紫微主星wrap＋北極三位逆行local-next」這幾個既有operator，特定地用來生成成熟化權？

所以C1/C2現在應避免寫成「缺少古法composition」。

更精確寫法是：

> **古法composition grammar已直證；缺的是mature-Quan-specific composition adoption。**

---

## 五、四個生成階段與古法語法對應

### C1-global

重建：
【祿row carrier沿十干環前進一位】

古法grammar：
- ANCHOR
- ORDERED_PARALLEL_ROWS
- ORDINAL_COUNT

直接見證：
1563十變曜。

### POOL

重建：
【選紫微主宰；紫微主星環廉貞wrap為紫微】

古法grammar：
- SOVEREIGN_ANCHOR
- ORDERED_SEQUENCE
- WRAP

直接見證：
《捷覽》主星若動＋紫微六星逆行回首。

### C2-scope

重建：
【北極三位scope＋紫微逆行】

古法grammar：
- ANCHOR
- DIRECTION
- SCOPE_SWITCH

古法先例：
《捷覽》紫微逆行；《全書》斗君／鐵蛇證算法會在中段切換作用域與方向。

### C2-local

重建：
【把已得到的局部三carrier狀態作下一段輸入，沿8→1→6閉環前進一位】

古法grammar：
- OUTPUT_AS_NEXT_ANCHOR
- NESTED_COMPOSITION
- GROUP_MOVE
- WRAP

直接先例：
- 斗君／鐵蛇：前段輸出作後段anchor；
- 《捷覽》：主星帶群；
- 紫微六星：走到底回首。

---

## 六、§752後的最準確定級

### 已證

- 古代斗數確實把公式寫成歌訣；
- 古訣包含anchor、順逆、步數、隔位、前後位、對宮、回首、相對重掛；
- 古代斗數直接使用多段composition；
- 前段輸出可作下一段anchor；
- 中途可改方向、改作用域；
- 主星可帶動整個星群。

### 低自由度重建

- 把十變曜權offset套到固定星祿row；
- 依主宰角色選紫微，套紫微閉環廉→紫；
- 把北極三位與紫微逆行合成816 local-next；
- 將三段按此順序串接為成熟權。

### 尚未直證

唯一真正核心：

> 「成熟化權編表者明說／明示按上述特定composition組合。」

---

## 七、與§750相比，缺口再次縮小

§750：

【primitive近閉合】
＋【specific composition句未見】

§751：

【廉退紫入本身降為古典主星環successor】

§752：

【generic composition grammar也直接閉合】

所以目前歷史缺口可以縮成一句：

> **零件已有，操作文法已有，多段串接方式也已有；尚未出土的只剩「這一組零件正是用於成熟化權」的編表採用證詞。**

這與「沒有古文證明化權公式」已是完全不同的證據狀態。

## 八、下一步

§753只做一個高價值文本學問題：

> 南陽堂四化題下注【論生年干　挾火而化】中的「火」，是否可能是十變曜「火孛木金土月水炁計羅」算法層的殘留術語？

方法：
1. 前1581／明代星命、七政、琴堂、選擇類文本定向找「挾火／夾火／火而化」；
2. 要求與生年干、變曜、化曜、十曜、祿暗福耗等同語境；
3. 若無獨立早期見證，維持孤立異文／疑訛，不用於主鏈；
4. 若出現第二件同型早期技術語，才重開「十變曜文本化石」假說。
