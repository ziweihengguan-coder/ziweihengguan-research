# §755 Projection grammar：skip／保序／稀疏取項／回首均為古法直接語法（2026-10-05）

## 一、問題

§754已把C2兩條序列定級為：

- carrier側【紫→巨→梁】＝《捷覽》完整安星母序對既定殘差集合的B+保序誘導；
- slot側【丑→子→亥＝8→1→6】＝古文scope＋古文逆行的A inputs + B composition。

最後尚有一個可能被質疑的現代步驟：

> 從一條完整有序母序中，略去不屬於已定子集的項目，仍保留原方向與相對次序，必要時末端回首——這種projection/subsequence grammar是不是2026年的數學抽象？

本節專門審此。

新增並實跑：
- `research/four_hua_20260929/quan_755_projection_grammar_audit_20261005.js`

結果：
- skip without reorder＝古法直接；
- preserve direction across gaps＝古法直接；
- sparse subsequence＝古法直接；
- wrap after sparse selection＝古法直接；
- moving-start drop-prefix＝古法直接。

generic projection grammar可正式定級：

> **CLOSED / DIRECTLY WITNESSED**

---

## 二、1563《星學大成》十變曜：明說「不要念」但保留後續原序

十變曜在換生年干時，不是重排整條曜序，而是移動起點。

既有可執行例：
- 甲以火起；
- 到乙年時明說【火不要念】，改由孛起；
- 之後仍依原曜序：
  孛→木→金→土→月→水→炁→計→羅→火；
- 末云餘依此推。

這直接給：

【SKIP_PREFIX】
＋【PRESERVE_ORDER】
＋【MOVING_START】
＋【REPEAT】

所以「略去前項但不重排剩餘序列」不是現代subsequence概念才有。

---

## 三、1581《捷覽》紫微系：內部跳位但方向不變，末端回anchor

紫微系古訣：

> 紫微天機星逆行，隔一陽武天同情。  
> 又隔二位廉貞位，空三便是紫微星。

若把逆行十二宮從anchor依次編0～11，實際取位：

> 0, 1, 3, 4, 5, 8 → 回0

也就是：

- 0→1：直接；
- 略過2；
- 取3,4,5；
- 略過6,7；
- 取8；
- 再略過9,10,11；
- 回anchor 0。

整個過程中：
- 不因跳位而改變逆行方向；
- 被略過項不會重排已取項；
- 最後回首形成sparse closed cycle。

直接operator：
- SKIP_INTERNAL
- PRESERVE_DIRECTION
- SPARSE_SUBSEQUENCE
- WRAP_TO_ANCHOR

---

## 四、1581《捷覽》天府系：另一獨立正控

天府系順行：

> 天府太陰順貪狼，巨門天相與天梁。  
> 七殺空三破軍位，隔宮望見天府鄉。

相對順行十二宮取位：

> 0,1,2,3,4,5,6,10 → 回0

同樣：
- 先保持順行；
- 中間skip；
- 取稀疏子序；
- 最後wrap回天府。

所以projection grammar不是紫微逆行單一特例。

---

## 五、《玄藪／中天太極紫微數》再給同型舊名鏈

同型古訣：

> 太極天驛星逆行，隔一常雷至鳳凰，又隔二位天暴位，空三便是太極星。

與《捷覽》紫微六星鏈逐項同構：

- 太極＝紫微
- 天驛＝天機
- 太常＝太陽
- 天雷＝武曲
- 鳳凰＝天同
- 天暴＝廉貞

它再次證明：
- skip；
- 保持逆向；
- sparse subsequence；
- wrap。

不是晚明《捷覽》孤例。

---

## 六、套回C2 carrier projection

§751–754在不讀成熟權target的選擇階段已得到殘差carrier集合：

> {紫微、巨門、天梁}

《捷覽》有實際安星方向意義的完整母序：

> 紫微／天府 → 太陰 → 貪狼 → 巨門 → 天相 → 天梁 → 七殺 → 破軍

將不屬殘差集合者略去，保留母序方向：

> 紫微 → 巨門 → 天梁

這個操作形式現在已有直接古法grammar：

> 【skip不取項，但保持母序方向與相對次序】

所以§754的保序subsequence不再需要視為現代新發明。

但仍要守住界線：

古代口訣中的skip項是由各自口訣直接指定；
本研究的{紫,巨,梁}子集則是前一步C1＋pool normalize的殘差集合。

因此：

- generic projection grammar＝A/B直接閉合；
- specific residual-carrier projection＝B+重建。

---

## 七、負控：parent sequence不能事後自由挑

§754已指出，《紫微數》另一同表條目序抽同三carrier會得到：

> 天梁→巨門→紫微

是欲求cycle的反方向。

所以不能使用規則：

> 「只要找一張古表，使三顆順序剛好符合即可。」

合法parent必須先有獨立操作語義。

《捷覽》天府／紫微主星鏈符合：
- 本身是安星訣；
- 有明確順／逆方向；
- 有worked example；
- 有skip與wrap；
- 可anchor平移整組。

故它與普通名錄／表格的地位不同。

---

## 八、§755後C2可再次壓縮

目前各部件：

1. scope={亥,子,丑}  
   → 古文直接。

2. orientation=逆  
   → 《捷覽》紫微系直接。

3. slot output=丑→子→亥=8→1→6  
   → 前兩direct inputs唯一推出。

4. residual carrier set={紫,巨,梁}  
   → C1＋POOL target-free重建。

5. carrier parent sequence  
   → 《捷覽》直接安星母序。

6. projection grammar=skip while preserve order/direction + wrap  
   → 古法直接。

7. carrier projected order=紫→巨→梁  
   → 母序＋既定子集唯一推出。

因此C2中「怎麼從完整序列取三顆仍保序」這個抽象operation也可封板。

---

## 九、現在真正還沒直證的只剩一件事

不是：
- 古人會不會跳位；
- 會不會保序；
- 會不會回首；
- 會不會多段composition；
- 會不會把前一段輸出當下一段anchor；
- 會不會主星帶群；
- 會不會用局部三位；
- 會不會移動祿起點。

這些都已有古法明文。

唯一剩下：

> **成熟化權編表者是否真的選擇把「C1後殘差{紫,巨,梁}」投影到《捷覽》主星母序，並再套北極亥子丑＋紫微逆行，形成成熟乙壬癸權。**

即：

> specific mature-Quan adoption

而不是 generic algorithm grammar。

---

## 十、定級

### generic projection grammar
**CLOSED / DIRECTLY WITNESSED**

### specific residual carrier projection
**B+ LOW-FREEDOM RECONSTRUCTION**

### mature-Quan specific adoption
**U：未見作者自述**

## 十一、下一步

§756不宜再找新的generic operator，因為：
- §752 generic composition grammar已閉合；
- §755 generic projection grammar亦閉合。

下一步應做一次【歌訣算法主線最終最小充分鏈重算】：
1. 把§751廉→紫 successor更新；
2. 把§752 multi-stage composition grammar更新；
3. 把§755 projection grammar更新；
4. 重新做一次最小自由度／消融；
5. 檢查是否還存在任何「沒有古法grammar先例」的現代primitive。

若結果為0，則可把歷史定級再精確提升為：

> **所有operator grammar均古法有據；specific composition adoption未直證。**
