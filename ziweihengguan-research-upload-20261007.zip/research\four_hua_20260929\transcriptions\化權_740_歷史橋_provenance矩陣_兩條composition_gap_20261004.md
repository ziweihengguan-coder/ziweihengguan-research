# §740 化權歷史橋最終provenance矩陣：古法primitive幾乎齊全，真正只剩兩條composition adoption沒有自述

日期：2026-10-04

## 一、為何要重新命名「歷史原訣缺口」

截至§739，若仍籠統說：

【化權公式沒有古文證明】

已經不夠精確。

因為目前成熟10/10重建所需的大多數操作元件，都已能在前1581或1581文本中找到直接／同型古法：

- 固定星祿row；
- 以祿為anchor的有序派生；
- 十變曜依生年干移動起點＋role位次；
- 十變功能ontology進入固定星系；
- 固定星可在固有化氣之外再接受生年四化tag；
- 北極三位scope；
- 紫微逆行orientation；
- 稀疏跳位後回首cycle；
- 主星帶動星群；
- 成熟化權表本身。

真正還未見的是：

> **古代編表者明說「我把這些已存在的元件這樣組合起來」。**

因此剩餘問題應改稱【composition provenance gap／組合採用來源缺口】。

## 二、九個歷史邊逐項審計

新增：
`research/four_hua_20260929/quan_740_historical_bridge_provenance_matrix_20261004.js`

### E1：早期固定星祿row存在
- 證據：《紫微數》p.21。
- 等級：A。
- 古法primitive：有。

### E2：十變曜從祿anchor依生年干動態取role
- 證據：1563《星學大成》甲求化貴、乙「火不要念，只念孛起」等讀表例。
- 等級：A。
- 古法primitive：有。

### E3：十變功能ontology進入固定星身份
- 證據：1581《捷覽》十變十role在固定星本性10/10覆蓋。
- 等級：B+，待原刻頁升A。
- 古法primitive：有。

### E4：fixed carrier可再接受另一個生年化曜tag
- 證據：《捷覽》【巨門其星化暗……更有吉化】＋卷一生年四化表；全40格量化36/38已知本性assignment為不同role。
- 等級：B+/A-。
- 古法primitive：有。

### C1：把十變「權=祿前一干」專門套到早期固定星祿row
- 結構：§730直接生成Q0 7/10，十個role中權唯一斷層第一。
- 作者直文：未見。
- 等級：C。
- 這是第一條真正composition gap。

### E5：權pool中「廉退紫入」
- 文本元件：紫微＝帝座／主宰；廉貞＝化囚；早期六星鏈中紫微是唯一未入祿pool者。
- 結構：在既定functional constraint下廉退紫入為最低複雜度。
- 古代元件：有。
- 「編表者正因這個理由換星」自述：未見。
- 等級：B/C selector reconstruction。

### E6：三殘差的scope／direction／cycle primitive
- 北極／北辰三位；
- 紫微逆行；
- 斗數跳位回首；
- 太一／九宮循環與816方向平行古法。
- 等級：A/B。
- 古法primitive：有。

### C2：把上述scope/orientation專門套到成熟權乙壬癸殘差
- §711–§714已target-free唯一生成成熟10/10。
- 但古代編表者沒有留下「化權乙壬癸就用這個局部環」一句。
- 等級：C。
- 這是第二條核心composition gap。

### V：成熟化權表
- 1581《捷覽》成熟權表。
- validation：10/10。

## 三、腳本結果

§740矩陣實跑：

- missing ancient-operation primitives：2個，C1、C2；
- 更精確地說，這兩個不是「沒有古代操作類型」，而是沒有【specific composition/adoption】直文；
- explicit composition/adoption尚缺C1、E5、C2三項；
- 核心公式真正的兩個composition gap＝【C1、C2】。

因此：

【primitive provenance】
已接近閉合；

【composition provenance】
尚缺兩條作者採用邊。

## 四、這對「歷史原訣」的定義很重要

若未來找到一句：

【祿前一干為權／依祿次取權】並且明確作用於固定星十干row，

即可直接關閉C1。

若找到一句：

【權取北極三位／紫微逆行而移權／乙壬癸依某三位輪轉】，

即可直接關閉C2。

只要其中一條出土，歷史鏈就會大幅升級。

但再找到一般：
- 次第；
- 周而復始；
- 太極；
- 化權；
- 從祿；
- 紫微逆行；

若沒有把它們接到上述specific input/output，就不再重複計證。

## 五、目前最精確的總結

成熟化權現在可分兩種「完成度」：

### 算法／約束層
【已完成10/10】
而且§713–§714消融、跨版本穩健性、target-free selector均已做過。

### 歷史機制primitive層
【幾乎閉合】
祿anchor、十變operator、fixed-star re-tagging、北極scope、逆行、cycle等都有古典操作來源。

### 歷史composition provenance層
【仍缺C1＋C2作者採用直文】

所以今後不再說：
「我們只找到一個現代公式，缺古文。」

應改說：

> **我們已重建出10/10公式，其幾乎所有運算primitive皆有古法來源；目前未出土的是編表者把這些primitive串成成熟化權的兩條specific composition說明。**

## 六、下一步 §741

若繼續追歷史原訣，搜尋應分成兩個完全獨立的小靶：

### C1靶：祿row→權offset
只接受：
- 祿前一干為權；
- 從祿數權；
- 依祿位取權；
- 固定星十干表與十變曜權位同段明接。

### C2靶：乙壬癸→816 local rewrite
只接受：
- 化權＋北極／亥子丑三位；
- 紫微逆行＋化權；
- 乙壬癸＋三位輪轉；
- 紫微／巨門／天梁＋權位移動。

其他一般相似語句全部停損。

§741應先做C1，因為它只差一個短操作句，而且1563十變曜已有完整讀表語法；若C1先閉合，整個Q0 7/10歷史骨架就能從C級升到直接傳承鏈，再單獨處理C2。
